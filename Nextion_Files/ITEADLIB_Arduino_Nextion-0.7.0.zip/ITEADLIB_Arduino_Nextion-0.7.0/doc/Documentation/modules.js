var modules =
[
    [ "Get Started", "group___get_started.html", null ],
    [ "Configuration", "group___configuration.html", "group___configuration" ],
    [ "Nextion Component", "group___component.html", "group___component" ],
    [ "Core API", "group___core_a_p_i.html", "group___core_a_p_i" ]
];